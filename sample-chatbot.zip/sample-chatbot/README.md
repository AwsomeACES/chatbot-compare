﻿# Deterministic sample chatbot fixture
